// Simple in-memory "database" of books.
// In a real app this would come from an API call.
const books = [
  { id: "101", title: "The Silent Library", author: "Maya Ford", price: 12.99, genre: "Mystery", rating: 4.6, stock: 7, pages: 312, published: 2022,
    description: "A librarian discovers a hidden room full of books that were never meant to be read." },
  { id: "102", title: "Beyond the Orchard", author: "Daniel Cho", price: 9.49, genre: "Fiction", rating: 4.3, stock: 14, pages: 288, published: 2021,
    description: "A quiet story about three siblings returning to their family farm after twenty years apart." },
  { id: "103", title: "Circuits of Tomorrow", author: "Priya Nathan", price: 15.0, genre: "Science Fiction", rating: 4.8, stock: 3, pages: 401, published: 2023,
    description: "An engineer builds an AI companion that starts asking questions no one can answer." },
  { id: "104", title: "The Cartographer's Widow", author: "Elena Ruiz", price: 13.5, genre: "Historical", rating: 4.5, stock: 9, pages: 356, published: 2020,
    description: "In 1920s Lisbon, a mapmaker's widow inherits a set of charts that don't match any known coastline." },
  { id: "105", title: "Low Tide at Everwood", author: "Sam Ilić", price: 10.99, genre: "Fiction", rating: 4.1, stock: 11, pages: 264, published: 2024,
    description: "A coastal town's yearly ritual is disrupted when the tide fails to come in on schedule." },
  { id: "106", title: "The Debt of Crows", author: "Mireille Aubert", price: 14.25, genre: "Fantasy", rating: 4.7, stock: 5, pages: 448, published: 2019,
    description: "A thief who owes a debt to a murder of crows must repay it before her shadow is taken instead." },
  { id: "107", title: "Notes on a Vanishing Coastline", author: "Priya Nathan", price: 11.75, genre: "Nonfiction", rating: 4.4, stock: 16, pages: 224, published: 2023,
    description: "A field biologist's decade of notes on the towns being slowly reclaimed by the sea." },
  { id: "108", title: "Static and Salt", author: "Owen Baptiste", price: 12.0, genre: "Science Fiction", rating: 4.0, stock: 0, pages: 298, published: 2022,
    description: "A radio operator on an abandoned research station starts picking up transmissions from before the station existed." },
  { id: "109", title: "The Understudy's Ghost", author: "Daniel Cho", price: 13.99, genre: "Mystery", rating: 4.2, stock: 8, pages: 336, published: 2021,
    description: "When a West End understudy dies on opening night, the theatre insists the show has never once stopped." },
];

export const genres = ["All", ...Array.from(new Set(books.map((b) => b.genre)))];

// Deterministic accent color per book, used for the generated "cover" tiles.
const PALETTE = ["#33513F", "#5A4632", "#4A5C73", "#7A3B34", "#5C4A72", "#3E5A5A", "#7A5A2E", "#44544A"];
export function colorForBook(id) {
  return PALETTE[parseInt(id, 10) % PALETTE.length];
}

export default books;
