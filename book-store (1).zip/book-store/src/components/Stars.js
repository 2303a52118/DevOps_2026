import React from "react";

function Stars({ rating }) {
  const full = Math.round(rating);
  return (
    <span className="rating">
      {"★".repeat(full)}
      {"☆".repeat(5 - full)}  {rating.toFixed(1)}
    </span>
  );
}

export default Stars;
