import React from "react";
import { NavLink } from "react-router-dom";

function Navbar({ cartCount }) {
  const linkClass = ({ isActive }) => `nav-link${isActive ? " active" : ""}`;

  return (
    <header className="top-nav">
      <div className="brand">
        <span className="mark">Leaflet &amp; Co.</span>
        <span className="tag">est. 2019 · independent booksellers</span>
      </div>
      <nav className="nav-links">
        <NavLink to="/" className={linkClass} end>
          Home
        </NavLink>
        <NavLink to="/books" className={linkClass}>
          Books
        </NavLink>
        <NavLink to="/cart" className={linkClass}>
          Cart
        </NavLink>
        <NavLink to="/about" className={linkClass}>
          About
        </NavLink>
        <NavLink to="/cart" className="cart-pill">
          Cart · {cartCount}
        </NavLink>
      </nav>
    </header>
  );
}

export default Navbar;
