import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import books, { colorForBook } from "../data/books";
import Stars from "./Stars";

// Simulates an async API call to fetch a single book by id.
function fetchBookById(id) {
  return new Promise((resolve) => {
    const found = books.find((b) => b.id === id) || null;
    setTimeout(() => resolve(found), 550);
  });
}

function BookDetails({ onAddToCart }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    let isCancelled = false; // guards against setting state after unmount/param change
    console.log(`[BookDetails] Mounting / id changed -> fetching book ${id}`);

    setLoading(true);
    setBook(null);
    setAdded(false);

    fetchBookById(id).then((result) => {
      if (!isCancelled) {
        setBook(result);
        setLoading(false);
      }
    });

    // Cleanup function: runs before the effect re-runs (id changes) and on unmount.
    return () => {
      isCancelled = true;
      console.log(`[BookDetails] Cleaning up effect for book ${id}`);
    };
  }, [id]); // Re-run whenever the route param `id` changes

  if (loading) {
    return <p className="loading">Loading book details...</p>;
  }

  if (!book) {
    return (
      <div>
        <h2>Book not found</h2>
        <p>
          No book matches id <code>{id}</code>.
        </p>
        <div className="row">
          <button className="btn btn-secondary" onClick={() => navigate(-1)}>
            Go back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="detail-cover" style={{ background: colorForBook(book.id) }}>
        {book.title}
      </div>
      <span className="genre-tag">{book.genre}</span>
      <h1>{book.title}</h1>
      <p className="meta-line">
        by {book.author} · {book.pages} pages · published {book.published}
      </p>
      <Stars rating={book.rating} />
      <p className="detail-price">${book.price.toFixed(2)}</p>
      <p>{book.description}</p>
      <p
        className={`stock ${book.stock === 0 ? "low" : "ok"}`}
        style={{ display: "block", clear: "both" }}
      >
        {book.stock === 0 ? "Currently out of stock" : `${book.stock} copies available`}
      </p>

      <div className="row">
        <button className="btn btn-secondary" onClick={() => navigate(-1)}>
          Go back
        </button>
        <button
          className="btn btn-primary"
          disabled={book.stock === 0}
          onClick={() => {
            onAddToCart(book);
            setAdded(true);
          }}
        >
          {book.stock === 0 ? "Out of stock" : added ? "Added ✓" : "Add to cart"}
        </button>
      </div>
    </div>
  );
}

export default BookDetails;
