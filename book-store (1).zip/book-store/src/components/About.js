import React from "react";

function About() {
  return (
    <div>
      <h1>About Leaflet &amp; Co.</h1>
      <p>
        We're a small independent bookshop stocking a tightly curated shelf rather than everything
        in print — every title here has been read by someone on staff first.
      </p>
      <p>
        This app is also a demo of client-side routing, route parameters, and component lifecycle
        (useEffect loading + cleanup) built with React and react-router-dom.
      </p>
    </div>
  );
}

export default About;
