import React from "react";
import { useNavigate } from "react-router-dom";
import books, { genres } from "../data/books";

function Home() {
  const navigate = useNavigate();

  return (
    <div className="hero">
      <div className="hero-copy">
        <h1>Read something you'll remember.</h1>
        <p className="lede">
          A small, considered shelf of {books.length} titles across mystery, fiction, fantasy and
          more — each one picked, not just stocked.
        </p>
        <div className="row">
          <button className="btn btn-primary" onClick={() => navigate("/books")}>
            Browse the shelf
          </button>
        </div>
        <div className="hero-stats">
          <div className="stat">
            <b>{books.length}</b>
            <span>titles in stock</span>
          </div>
          <div className="stat">
            <b>{genres.length - 1}</b>
            <span>genres</span>
          </div>
          <div className="stat">
            <b>4.4</b>
            <span>avg. rating</span>
          </div>
        </div>
      </div>
      <div className="hero-visual">
        <div className="spine" style={{ left: "22px", background: "rgba(250,246,238,0.22)" }} />
        <div className="spine" style={{ left: "70px" }} />
        <div className="spine" style={{ left: "118px", background: "rgba(250,246,238,0.28)" }} />
        <div className="spine" style={{ left: "166px" }} />
      </div>
    </div>
  );
}

export default Home;
