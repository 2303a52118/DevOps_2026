import React from "react";
import { Link } from "react-router-dom";

function Cart({ cartItems }) {
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  if (cartItems.length === 0) {
    return (
      <div>
        <h1>Your cart</h1>
        <div className="empty-cart-visual" />
        <p className="empty">Nothing here yet.</p>
        <Link to="/books">
          <button className="btn btn-secondary">Browse books</button>
        </Link>
      </div>
    );
  }

  return (
    <div>
      <h1>Your cart</h1>
      <ul className="cart-list">
        {cartItems.map((item, index) => (
          <li key={index}>
            <span>{item.title}</span>
            <span>${item.price.toFixed(2)}</span>
          </li>
        ))}
      </ul>
      <p className="total">Total: ${total.toFixed(2)}</p>
      <button className="btn btn-primary" style={{ marginTop: 10 }}>
        Checkout
      </button>
    </div>
  );
}

export default Cart;
