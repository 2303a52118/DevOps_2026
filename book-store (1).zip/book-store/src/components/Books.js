import React, { useState } from "react";
import { Link } from "react-router-dom";
import books, { genres, colorForBook } from "../data/books";
import Stars from "./Stars";

function Books() {
  const [filter, setFilter] = useState("All");
  const shown = filter === "All" ? books : books.filter((b) => b.genre === filter);

  return (
    <div>
      <h1>All books</h1>
      <p style={{ opacity: 0.65, marginTop: -6 }}>
        {shown.length} of {books.length} titles
      </p>

      <div className="filters">
        {genres.map((g) => (
          <button
            key={g}
            className={filter === g ? "active" : ""}
            onClick={() => setFilter(g)}
          >
            {g}
          </button>
        ))}
      </div>

      <div className="grid">
        {shown.map((book) => (
          <div className="card" key={book.id}>
            <div className="cover" style={{ background: colorForBook(book.id) }}>
              {book.stock === 0 && <span className="badge">Sold out</span>}
              {book.stock > 0 && book.stock <= 3 && <span className="badge">Low stock</span>}
              {book.title}
            </div>
            <div className="card-body">
              <span className="genre-tag">{book.genre}</span>
              <h3>{book.title}</h3>
              <p className="author">{book.author}</p>
              <Stars rating={book.rating} />
              <div className="price-row">
                <span className="price">${book.price.toFixed(2)}</span>
                <span className={`stock ${book.stock === 0 ? "low" : "ok"}`}>
                  {book.stock === 0 ? "Out of stock" : `${book.stock} left`}
                </span>
              </div>
              <Link to={`/books/${book.id}`}>
                <button className="btn btn-secondary">View details</button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Books;
