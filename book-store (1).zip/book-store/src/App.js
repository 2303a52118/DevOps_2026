import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";

import "./App.css";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Books from "./components/Books";
import BookDetails from "./components/BookDetails";
import Cart from "./components/Cart";
import About from "./components/About";
import NotFound from "./components/NotFound";

function App() {
  const [cartItems, setCartItems] = useState([]);

  const handleAddToCart = (book) => {
    setCartItems((prev) => [...prev, book]);
  };

  return (
    <div className="app">
      <Navbar cartCount={cartItems.length} />

      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/books" element={<Books />} />
          <Route
            path="/books/:id"
            element={<BookDetails onAddToCart={handleAddToCart} />}
          />
          <Route path="/cart" element={<Cart cartItems={cartItems} />} />
          <Route path="/about" element={<About />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <footer className="app-footer">
        Leaflet &amp; Co. — a demo bookstore. Not a real store; nothing here ships.
      </footer>
    </div>
  );
}

export default App;
