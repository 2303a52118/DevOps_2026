# Leaflet & Co. — Online Book Store (React Routing + Lifecycle Demo)

## Setup

1. Install Node.js (v16+) and open this folder in VS Code.
2. Install dependencies:
   ```
   npm install
   ```
   (`react-router-dom` is already listed in package.json, so this installs it too.)
3. Start the dev server:
   ```
   npm start
   ```
4. Open http://localhost:3000 — the app should load with no page reloads while navigating.

## Project Structure

```
src/
  index.js              - entry point, wraps <App /> in <BrowserRouter>
  App.js                - route definitions + cart state
  App.css               - storefront styling (nav, hero, cards, grid)
  data/books.js          - 9 books (ids 101-109) with rating, stock, pages, genre
  components/
    Navbar.js            - NavLink navigation, brand mark, live cart count pill
    Home.js               - hero section with shelf stats
    Books.js              - genre filter + book grid, links to /books/:id
    BookDetails.js        - useParams + useEffect + loading + cleanup + stock-aware Add to Cart
    Stars.js              - small star-rating renderer
    Cart.js
    About.js
    NotFound.js           - catch-all 404 route
```

## How each requirement is met

- **Routing**: `/`, `/books`, `/books/:id`, `/cart`, `/about`, and a `*` catch-all are all
  configured in `App.js` using `<Routes>` / `<Route>`.
- **Navigation**: `Navbar.js` uses `NavLink` so the active route is highlighted.
- **useParams()**: `BookDetails.js` reads the `:id` segment with `useParams()`.
- **Lifecycle**: `BookDetails.js`'s `useEffect` runs on mount and again whenever `id`
  changes (dependency array `[id]`). It sets `loading` to `true` immediately, "fetches"
  the book (simulated with a 600ms delay), and returns a cleanup function that marks
  the request as cancelled — preventing state updates from a stale request if you
  navigate to another book before the first one finishes loading.
- **Loading state**: "Loading book details..." is shown until the fetch resolves.
- **Invalid ID**: if no book matches the id, "Book Not Found" is shown instead.
- **Add to Cart / Cart count**: `App.js` holds `cartItems` state; `BookDetails` calls
  `onAddToCart`, and `Navbar` displays the live count.
- **Go Back**: `BookDetails.js` has a "Go Back" button using `useNavigate()(-1)`.

## Try it out

- Go to Books, filter by genre, and click into a few titles (ids **101–109**) to watch
  the console logs showing the effect re-running and cleaning up on each id change.
- Book **108** ("Static and Salt") has 0 stock — its Add to Cart button is disabled
  both on the card badge and on the detail page.
- Visit a bad URL like `/books/999` to see "Book Not Found".
- Visit a random path like `/xyz` to see the 404 NotFound page.
