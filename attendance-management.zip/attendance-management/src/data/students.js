// Sample student records.
// `attended` / `total` are cumulative class counts so the attendance
// percentage can be derived and recalculated as Present/Absent is marked.
export const initialStudents = [
  { id: 1, name: 'Aarav Sharma', roll: 'CSE001', branch: 'Computer Science', attended: 34, total: 40 },
  { id: 2, name: 'Priya Reddy', roll: 'ECE002', branch: 'Electronics', attended: 28, total: 40 },
  { id: 3, name: 'Rohan Verma', roll: 'MECH003', branch: 'Mechanical', attended: 25, total: 40 },
  { id: 4, name: 'Sneha Iyer', roll: 'CSE004', branch: 'Computer Science', attended: 38, total: 40 },
  { id: 5, name: 'Karthik Nair', roll: 'CIVIL005', branch: 'Civil', attended: 22, total: 40 },
  { id: 6, name: 'Ananya Rao', roll: 'ECE006', branch: 'Electronics', attended: 30, total: 40 },
  { id: 7, name: 'Divya Menon', roll: 'IT007', branch: 'Information Technology', attended: 33, total: 40 },
  { id: 8, name: 'Farhan Ali', roll: 'CSE008', branch: 'Computer Science', attended: 20, total: 40 },
];
