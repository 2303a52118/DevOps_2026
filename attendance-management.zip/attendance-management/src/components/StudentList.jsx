import StudentCard from './StudentCard.jsx';

function StudentList({ students, onMark }) {
  if (students.length === 0) {
    return (
      <div className="empty-state">
        <p>No students match that search.</p>
      </div>
    );
  }

  return (
    <div className="ledger">
      <div className="ledger-row ledger-head" aria-hidden="true">
        <div className="col-roll">Roll no.</div>
        <div className="col-student">Student</div>
        <div className="col-attendance">Attendance</div>
        <div className="col-status">Today</div>
      </div>

      {students.map((student) => (
        <StudentCard
          key={student.id}
          id={student.id}
          name={student.name}
          roll={student.roll}
          branch={student.branch}
          attended={student.attended}
          total={student.total}
          status={student.status}
          onMark={onMark}
        />
      ))}
    </div>
  );
}

export default StudentList;
