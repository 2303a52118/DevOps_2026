import Attendance from './Attendance.jsx';

function StudentCard({ id, name, roll, branch, attended, total, status, onMark }) {
  const percentage = total > 0 ? (attended / total) * 100 : 0;
  const isLow = percentage < 75;

  return (
    <div className={`ledger-row ${isLow ? 'is-low-attendance' : ''}`}>
      <div className="col-roll">
        <span className="roll-no">{roll}</span>
      </div>

      <div className="col-student">
        <span className="student-name">{name}</span>
        <span className="student-branch">{branch}</span>
      </div>

      <div className="col-attendance">
        <Attendance percentage={percentage} status={status} onMark={(newStatus) => onMark(id, newStatus)} />
      </div>

      <div className="col-status">
        {status ? (
          <span className={`today-tag ${status.toLowerCase()}`}>{status} today</span>
        ) : (
          <span className="today-tag pending">Not marked</span>
        )}
        {isLow && <span className="risk-flag">At risk</span>}
      </div>
    </div>
  );
}

export default StudentCard;
