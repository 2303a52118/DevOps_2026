function Header({ title, institution, session }) {
  const today = new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <header className="app-header">
      <div className="header-row">
        <div className="seal" aria-hidden="true">
          <svg viewBox="0 0 60 60" width="44" height="44">
            <circle cx="30" cy="30" r="27" fill="none" stroke="currentColor" strokeWidth="1.4" />
            <circle cx="30" cy="30" r="21" fill="none" stroke="currentColor" strokeWidth="1" />
            <text x="30" y="35" textAnchor="middle" fontSize="15" fontFamily="'IBM Plex Serif', serif" fill="currentColor">
              KIT
            </text>
          </svg>
        </div>
        <div className="header-text">
          <p className="institution-name">{institution}</p>
          <h1>{title}</h1>
        </div>
        <div className="header-meta">
          <span>{session}</span>
          <span>{today}</span>
        </div>
      </div>
    </header>
  );
}

export default Header;
