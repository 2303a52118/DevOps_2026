function Summary({ total, presentToday, absentToday, notMarked, eligibleCount, avgAttendance }) {
  const stats = [
    { label: 'Total students', value: total },
    { label: 'Present today', value: presentToday, tone: 'present' },
    { label: 'Absent today', value: absentToday, tone: 'absent' },
    { label: 'Not marked', value: notMarked, tone: 'pending' },
    { label: 'Eligible (75%+)', value: eligibleCount, tone: 'eligible' },
    { label: 'Average attendance', value: `${avgAttendance}%` },
  ];

  return (
    <div className="summary-strip">
      {stats.map((stat, index) => (
        <div className={`summary-stat ${stat.tone || ''}`} key={stat.label}>
          <span className="stat-value">{stat.value}</span>
          <span className="stat-label">{stat.label}</span>
          {index < stats.length - 1 && <span className="stat-divider" aria-hidden="true" />}
        </div>
      ))}
    </div>
  );
}

export default Summary;
