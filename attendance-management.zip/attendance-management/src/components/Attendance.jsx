const ELIGIBILITY_THRESHOLD = 75;

function Attendance({ percentage, status, onMark }) {
  const isEligible = percentage >= ELIGIBILITY_THRESHOLD;
  const fillWidth = Math.min(percentage, 100);

  return (
    <div className="attendance">
      <div className="gauge" role="img" aria-label={`${percentage.toFixed(1)} percent attendance`}>
        <div className="gauge-track">
          <div className={`gauge-fill ${isEligible ? 'is-eligible' : 'is-low'}`} style={{ width: `${fillWidth}%` }} />
          <div className="gauge-threshold" style={{ left: `${ELIGIBILITY_THRESHOLD}%` }} />
        </div>
        <div className="gauge-readout">
          <span className="gauge-percent">{percentage.toFixed(1)}%</span>
          <span className={`eligibility-badge ${isEligible ? 'eligible' : 'not-eligible'}`}>
            {isEligible ? 'Eligible' : 'Not Eligible'}
          </span>
        </div>
      </div>

      <div className="mark-controls">
        <button
          type="button"
          className={`stamp-btn present ${status === 'Present' ? 'is-active' : ''}`}
          onClick={() => onMark('Present')}
        >
          Present
        </button>
        <button
          type="button"
          className={`stamp-btn absent ${status === 'Absent' ? 'is-active' : ''}`}
          onClick={() => onMark('Absent')}
        >
          Absent
        </button>
      </div>
    </div>
  );
}

export default Attendance;
