function SearchBar({ searchTerm, onSearchChange }) {
  return (
    <div className="search-bar">
      <svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true">
        <circle cx="8.5" cy="8.5" r="6" fill="none" stroke="currentColor" strokeWidth="1.6" />
        <line x1="13.2" y1="13.2" x2="18" y2="18" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
      <input
        type="text"
        placeholder="Search by name or roll number"
        value={searchTerm}
        onChange={(event) => onSearchChange(event.target.value)}
        aria-label="Search students"
      />
      {searchTerm && (
        <button type="button" className="clear-search" onClick={() => onSearchChange('')} aria-label="Clear search">
          ×
        </button>
      )}
    </div>
  );
}

export default SearchBar;
