import { useState } from 'react';
import Header from './components/Header.jsx';
import SearchBar from './components/SearchBar.jsx';
import StudentList from './components/StudentList.jsx';
import Summary from './components/Summary.jsx';
import { initialStudents } from './data/students.js';

function withNoStatus(list) {
  return list.map((student) => ({ ...student, status: null }));
}

function App() {
  // Single source of truth for every student's cumulative attendance + today's status.
  const [students, setStudents] = useState(() => withNoStatus(initialStudents));
  const [searchTerm, setSearchTerm] = useState('');

  // Update one student's record when a faculty member marks Present/Absent.
  const handleMark = (id, status) => {
    setStudents((prev) =>
      prev.map((student) => {
        if (student.id !== id) return student;
        if (status === 'Present') {
          return { ...student, attended: student.attended + 1, total: student.total + 1, status: 'Present' };
        }
        return { ...student, total: student.total + 1, status: 'Absent' };
      })
    );
  };

  const handleReset = () => {
    setStudents(withNoStatus(initialStudents));
  };

  const filteredStudents = students.filter((student) => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return true;
    return student.name.toLowerCase().includes(term) || student.roll.toLowerCase().includes(term);
  });

  // Derived summary statistics - recomputed from state on every render, never duplicated in state.
  const total = students.length;
  const presentToday = students.filter((s) => s.status === 'Present').length;
  const absentToday = students.filter((s) => s.status === 'Absent').length;
  const notMarked = total - presentToday - absentToday;
  const eligibleCount = students.filter((s) => (s.attended / s.total) * 100 >= 75).length;
  const avgAttendance = total
    ? (students.reduce((sum, s) => sum + (s.attended / s.total) * 100, 0) / total).toFixed(1)
    : '0.0';

  return (
    <div className="app">
      <Header title="Student Attendance Management System" institution="Kaveri Institute of Technology" session="B.Tech · Semester 5" />

      <main className="app-main">
        <Summary
          total={total}
          presentToday={presentToday}
          absentToday={absentToday}
          notMarked={notMarked}
          eligibleCount={eligibleCount}
          avgAttendance={avgAttendance}
        />

        <div className="toolbar">
          <SearchBar searchTerm={searchTerm} onSearchChange={setSearchTerm} />
          <button type="button" className="reset-btn" onClick={handleReset}>
            Reset attendance
          </button>
        </div>

        <StudentList students={filteredStudents} onMark={handleMark} />
      </main>

      <footer className="app-footer">
        <p>Attendance below 75% is flagged &ldquo;At risk&rdquo; and marked Not Eligible for end-semester exams.</p>
      </footer>
    </div>
  );
}

export default App;
