# Student Attendance Management System

A React dashboard where faculty can view a student roster and mark daily
Present/Absent attendance, with live percentage, eligibility, and summary
statistics. Built with **React 18 + Vite**.

## 1. Setup

You need **Node.js** (v18+) and a code editor (e.g. VS Code) installed.

```bash
# 1. Unzip the project, then move into it
cd attendance-management

# 2. Install dependencies
npm install

# 3. Start the development server
npm start        # (alias for `npm run dev`, so either command works)
```

The terminal will print a local URL (typically `http://localhost:3000`).
Open it in your browser to verify the app is running.

Other scripts:
- `npm run build` – production build to `dist/`
- `npm run preview` – preview the production build locally

## 2. Project structure

```
attendance-management/
├─ index.html
├─ package.json
├─ vite.config.js
└─ src/
   ├─ main.jsx              # mounts <App /> into the DOM
   ├─ App.jsx                # owns state, handlers, derived summary stats
   ├─ index.css              # design system (ledger/register visual style)
   ├─ data/
   │  └─ students.js         # sample student dataset
   └─ components/
      ├─ Header.jsx          # application title / letterhead
      ├─ SearchBar.jsx       # filter roster by name / roll no.
      ├─ StudentList.jsx     # renders column head + one StudentCard per student
      ├─ StudentCard.jsx     # one student's row; embeds <Attendance />
      ├─ Attendance.jsx      # gauge, eligibility badge, Present/Absent buttons
      └─ Summary.jsx         # today's tally strip (totals, present, absent, avg)
```

## 3. How data flows (state + props)

- `App.jsx` holds the **single source of truth**: a `students` array in
  `useState`, each record storing `{ id, name, roll, branch, attended, total, status }`.
- `App` passes the array down to **StudentList** via props.
- **StudentList** maps over the array and passes each student's individual
  fields (`name`, `roll`, `branch`, `attended`, `total`, `status`) plus the
  `onMark` handler down to **StudentCard** as props.
- **StudentCard** derives the attendance percentage and passes it, along with
  `status` and a bound `onMark`, down to **Attendance**.
- **Attendance** renders the Present/Absent buttons. Clicking one calls
  `onMark`, which bubbles back up to `App`, where `setStudents` updates that
  student's `attended`/`total`/`status` — React re-renders the whole tree with
  the new percentage.
- Summary statistics (`presentToday`, `absentToday`, `eligibleCount`,
  `avgAttendance`, etc.) are **derived from state on every render** in `App`
  and passed down to **Summary** as props — nothing is duplicated in state.

## 4. Requirements checklist

| Requirement | Where |
|---|---|
| Header / StudentList / StudentCard / Attendance / Summary components | `src/components/` |
| Props: student details StudentList → StudentCard | `StudentList.jsx` |
| Props: name & roll number passed explicitly | `StudentCard.jsx` |
| Props: attendance info → Attendance component | `StudentCard.jsx` → `Attendance.jsx` |
| Props: summary info → Summary component | `App.jsx` → `Summary.jsx` |
| `useState` for attendance | `App.jsx` |
| Present / Absent buttons update state | `Attendance.jsx`, `App.jsx: handleMark` |
| Dynamic attendance percentage | `StudentCard.jsx` (derived each render) |
| Total present / absent counts | `App.jsx` derived stats → `Summary.jsx` |
| Conditional rendering: Eligible / Not Eligible (≥75%) | `Attendance.jsx` |
| **Bonus:** Reset Attendance button | `App.jsx: handleReset` |
| **Bonus:** Search box | `SearchBar.jsx` |
| **Bonus:** Present/absent counts displayed | `Summary.jsx` |
| **Bonus:** Highlight attendance below 75% | `StudentCard.jsx` (`.is-low-attendance`) |

## 5. Customizing the data

Edit `src/data/students.js` to add, remove, or change students. Each record
just needs `id`, `name`, `roll`, `branch`, `attended`, and `total` — the
percentage, eligibility, and summary numbers are all calculated automatically.
